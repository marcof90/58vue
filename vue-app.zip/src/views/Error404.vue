<template>
    <div>
        <app-header></app-header>
        <div class="container text-center mt-5">
            <h1>404</h1>
            <h2>Page not found</h2>
        </div>
    </div>
</template>

<script>
import AppHeader from '@/components/AppHeader';

export default {
    components:{
        AppHeader
    }    
}
</script>